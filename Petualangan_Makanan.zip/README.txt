# Petualangan Makanan — Sistem Pencernaan

Media HTML5 interaktif untuk IPAS SD.
Cara menjalankan:
1. Ekstrak ZIP.
2. Buka `index.html` menggunakan Chrome/Edge/Firefox.
3. Untuk menjadi website online, upload seluruh isi folder ke GitHub Pages, Netlify, atau hosting sekolah.
